import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dateinput-demo',
  templateUrl: './dateinput-demo.component.html',
  styleUrls: ['./dateinput-demo.component.scss']
})
export class DateInputDemoComponent implements OnInit {  
  today: Date;  
	minDate: Date;
  maxDate: Date;
  
  constructor() { 
    this.today = new Date();    
		this.minDate = new Date(2018, 6, 1);
		this.maxDate = new Date(this.today.getTime() + (24 * 60 * 60 * 1000));
  }

  ngOnInit() {
  }

}
