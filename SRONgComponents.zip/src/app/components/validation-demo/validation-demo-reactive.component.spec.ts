import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationDemoReactiveComponent } from './validation-demo-reactive.component';

describe('ValidationDemoReactiveComponent', () => {
  let component: ValidationDemoReactiveComponent;
  let fixture: ComponentFixture<ValidationDemoReactiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidationDemoReactiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidationDemoReactiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
