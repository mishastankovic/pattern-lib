import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'app-tabs-demo',
	templateUrl: './tabs-demo.component.html',
	styleUrls: ['./tabs-demo.component.scss']
})
export class TabsDemoComponent implements OnInit {

	constructor(private router: Router) { }

	ngOnInit() {
	}

}
