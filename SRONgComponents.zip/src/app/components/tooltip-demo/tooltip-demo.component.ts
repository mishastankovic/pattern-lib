import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'app-tooltip-demo',
	templateUrl: './tooltip-demo.component.html',
	styleUrls: ['./tooltip-demo.component.scss']
})
export class TooltipDemoComponent implements OnInit {

	constructor(private router: Router) { }

	ngOnInit() {
	}

}
