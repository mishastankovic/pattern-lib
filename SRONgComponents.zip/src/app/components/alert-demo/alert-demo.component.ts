import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { AlertService } from "SRONgComponentLibrary";

@Component({
	selector: 'app-alert-demo',
	templateUrl: './alert-demo.component.html',
	styleUrls: ['./alert-demo.component.scss']
})
export class AlertDemoComponent {

	constructor(private alertService: AlertService) {
	}

	onSuccessClicked() {
		this.alertService.success("Your action has been successfully completed.");
	}

	onErrorClicked() {
		this.alertService.error("You have made a critical error.");
	}

	onInformationClicked() {
		this.alertService.info("For more information please read <a href='#' target='_blank' class='alert-link'>this page</a> <em class='fa fa-external-link-alt'>");
	}

	onWarningClicked() {
		this.alertService.warn("You were warned not to click on Warning button.");
	}

	onDismissClicked() {
		this.alertService.successDismissable("You can close this success alert.");
		this.alertService.errorDismissable("You can close this error alert.");
		this.alertService.infoDismissable("You can close this informational alert.");
		this.alertService.warnDismissable("You can close this warning alert.");
	}

	onClearClicked() {
		this.alertService.clear();
	}
}