import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, Subject } from "rxjs";
import { map, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';

import { environment } from '../../environments/environment';
import { Address } from '../model/address';
import { MockAddress } from '../model/address-data-mock';


@Injectable()
export class IntechService {
	baseUrl: string = '';
	searchPath: string = '';
	standardisePath: string = '';

	constructor(private http: HttpClient, @Inject('env') private env) {
		if (env.serviceHostname !== '') this.baseUrl = env.serviceHostname;
		if (env.intechSearchServicePath !== '') this.searchPath = env.intechSearchServicePath;
		if (env.intechStandardiseServicePath !== '') this.standardisePath = env.intechStandardiseServicePath;
	}


	search(addressLine: string, vicOnly?: string, excludePostal?: string): Observable<string[]> {
		return this.searchAddress(addressLine, vicOnly, excludePostal);
	}

	private searchAddress(queryString: string, vicOnly?: string, excludePostal?: string): Observable<string[]> {
		const basePath: string = this.searchPath;
		const queryUrl: string = '?addressLine=';
		const victorianAddressesOnly: string = "&victorianAddressesOnly=";
		const excludePostalAddress: string = "&excludePostalAddress=";

		console.log("searchAddress endpoint:" + this.baseUrl + basePath + queryUrl + queryString + victorianAddressesOnly + vicOnly + excludePostalAddress + excludePostal);
		return this.http
			.get(this.baseUrl + basePath + queryUrl + queryString + victorianAddressesOnly + vicOnly + excludePostalAddress + excludePostal)
			.pipe(
			map((addresses: string[]) => {
				let result: string[] = [];
				if (addresses) addresses.forEach(item => result.push(item));
				return result;
			})
			);
	}

	standardise(queryString: string): Observable<Address> {
		return this.standardiseAddress(queryString);;
	}

	private standardiseAddress(queryString: string): Observable<Address> {
		const basePath: string = this.standardisePath;
		const queryUrl: string = '?addressLine=';

		return this.http
			.get<Address>(this.baseUrl + basePath + queryUrl + queryString);
	}

	private mockSearch(addressLine: string): Observable<string[]> {
		const query = new RegExp(addressLine, 'ig');
		return of(MockAddress.filter((address: any) => {
			return query.test(address);
		})
		);
	}

	private mockStandardiseAddress(addressLine: string): Observable<Address> {
		const mockAddress = Address.createAddress();
		if (addressLine.startsWith("121")) {
			mockAddress.addressFormatType = "STREET";
			mockAddress.roadNumberFrom = "121";
			mockAddress.roadName = "EXHIBITION";
			mockAddress.roadType = "ST";
			mockAddress.localityName = "MELBOURNE";
			mockAddress.postcode = "3000";
			mockAddress.stateTerritory = "VIC";
		}
		return of(mockAddress);
	}


	private getHeaders() {
		let headers = new HttpHeaders();
		headers.append('Accept', 'application/json');
		headers.append('Content-Type', 'application/json');
		return headers;
	}

}