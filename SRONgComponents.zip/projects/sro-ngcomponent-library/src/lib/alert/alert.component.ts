import { Component, OnInit, Input } from '@angular/core';
import { Alert, AlertType } from '../model/alert';
import { AlertService } from '../service/alert.service';

@Component({
	selector: 'sro-app-alert',
	templateUrl: './alert.component.html'
})
export class AlertComponent implements OnInit {
	@Input() id: string;

	alerts: Alert[] = [];

	constructor(private alertService: AlertService) { }

	ngOnInit() {
		this.alertService.getAlert(this.id).subscribe((alert: Alert) => {
			if (!alert || !alert.message) {
				// Clear alerts when an empty alert is received.
				this.alerts = [];
				return;
			}

			if (!this.alerts.some(x => x && x.type === alert.type && x.message === alert.message && x.alertId === alert.alertId && x.keepAfterRouteChange === alert.keepAfterRouteChange)) {
				// Add unique alert to array.
				this.alerts.push(alert);
			}
		});
	}

	removeAlert(alert: Alert) {
		this.alerts = this.alerts.filter(x => x !== alert);
	}

	cssClass(alert: Alert) {
		if (!alert) {
			return;
		}

		// Return CSS class based on alert type.
		switch (alert.type) {
			case AlertType.Success:
				return 'alert-success';
			case AlertType.Error:
				return 'alert-danger';
			case AlertType.Info:
				return 'alert-info';
			case AlertType.Warning:
				return 'alert-warning';
		}
	}

	cssDismissable(alert: Alert) {
		if (!alert) {
			return;
		}

		if (alert.dismissable)
			return 'alert-dismissable';
	}

}
