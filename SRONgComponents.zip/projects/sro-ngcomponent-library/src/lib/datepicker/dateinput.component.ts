import { Component, ViewChild, HostListener, Input } from '@angular/core';
import { BsDatepickerDirective } from './bs-datepicker.component';
import { BsDatepickerConfig } from './bs-datepicker.config';

// import { defineLocale } from '../chronos/locale/locales';
// import { enGbLocale } from '../chronos/i18n/en-gb';
// defineLocale('enGb', enGbLocale)

@Component({
  selector: 'sro-dateinput',
  templateUrl: './dateinput.component.html',
  styleUrls: ['./dateinput.component.css']
})

export class DateInputComponent {
  @ViewChild(BsDatepickerDirective) datepicker: BsDatepickerDirective;
  @Input() dateValue: Date;
  @Input() minDate: Date;
  @Input() maxDate: Date;
  @Input() isDisabled: Boolean = false;
  @Input() placement: 'top' | 'bottom' | 'left' | 'right' = 'bottom';  
  @Input() hideOnScroll: Boolean = false;
  // https://developer.mozilla.org/en-US/docs/Web/Events
  @Input() triggers: String = 'click'; 
  @Input() showWeekNumbers: Boolean = false;
  private _outsideClick: Boolean = true;
  
  get outsideClick(): Boolean {
    return this._outsideClick;
  }

  @Input()
  set outsideClick(value: Boolean) {    
    this._outsideClick = value;
  }

  public config: Partial<BsDatepickerConfig> = new BsDatepickerConfig();
  
  constructor() {  
    this.config.dateInputFormat = 'DD/MM/YYYY';    
    this.config.showWeekNumbers = this.showWeekNumbers.valueOf();    
  }

  @HostListener('window:scroll')
  onScrollEvent() {
    if (this.hideOnScroll)
      this.datepicker.hide();
  }
}
