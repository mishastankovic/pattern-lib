export { NgTranscludeDirective } from './ng-transclude.directive';
export { TabDirective } from './tab.directive';
export { TabHeadingDirective } from './tab-heading.directive';
export { TabsetComponent } from './tabset.component';
export { TabsetConfig } from './tabset.config';
export { TabsModule } from './tabs.module';
