import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { NgTranscludeDirective } from './ng-transclude.directive';
import { StepHeadingDirective } from './step-heading.directive';
import { StepDirective } from './step.directive';
import { StepperComponent } from './stepper.component';

@NgModule({
  imports: [CommonModule],
  declarations: [
    NgTranscludeDirective,
    StepDirective,
    StepperComponent,
    StepHeadingDirective
  ],
  exports: [
    StepDirective,
    StepperComponent,
    StepHeadingDirective,
    NgTranscludeDirective
  ]
})
export class StepsModule {}
