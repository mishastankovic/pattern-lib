import { Component, HostBinding, Input, OnDestroy, Renderer2 } from '@angular/core';

import { StepDirective } from './step.directive';
import { StepperConfig } from './stepper.config';
// todo: add active event to tab
// todo: fix? mixing static and dynamic steps position steps in order of creation
@Component({
  selector: 'sro-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss']
})
export class StepperComponent implements OnDestroy {

   /** tab id. The same id with suffix '-link' will be added to the corresponding &lt;li&gt; element  */
   @HostBinding('attr.id')
   @Input() id: string;
   
  /** if true steps will be placed vertically */
  @Input()
  get vertical(): boolean {
    return this._vertical;
  }
  set vertical(value: boolean) {
    this._vertical = value;
    this.setClassMap();
  }

  /** if true steps fill the container and have a consistent width */
  @Input()
  get justified(): boolean {
    return this._justified;
  }
  set justified(value: boolean) {
    this._justified = value;
    this.setClassMap();
  }

  /** navigation context class: 'steps' or 'pills' */
  @Input()
  get type(): string {
    return this._type;
  }
  set type(value: string) {
    this._type = value;
    this.setClassMap();
  }

  @HostBinding('class.stepper-container') clazz = true;

  currentStep: StepDirective;
  steps: StepDirective[] = [];
  classMap: any = {};

  protected isDestroyed: boolean;
  protected _vertical: boolean;
  protected _justified: boolean;
  protected _type: string;

  constructor(config: StepperConfig, private renderer: Renderer2) {
    Object.assign(this, config);
  }

  ngOnDestroy(): void {
    this.isDestroyed = true;
  }

  addTab(tab: StepDirective): void {
    this.steps.push(tab);
    tab.active = this.steps.length === 1 && typeof tab.active === 'undefined';
  }

  removeTab(
    tab: StepDirective,
    options = { reselect: true, emit: true }
  ): void {
    const index = this.steps.indexOf(tab);
    if (index === -1 || this.isDestroyed) {
      return;
    }
    // Select a new tab if the tab to be removed is selected and not destroyed
    if (options.reselect && tab.active && this.hasAvailablesteps(index)) {
      const newActiveIndex = this.getClosestTabIndex(index);
      this.steps[newActiveIndex].active = true;
    }
    if (options.emit) {
      tab.removed.emit(tab);
    }
    this.steps.splice(index, 1);
    if (tab.elementRef.nativeElement.parentNode) {
      this.renderer.removeChild(
        tab.elementRef.nativeElement.parentNode,
        tab.elementRef.nativeElement
      );
    }
  }
  protected getClosestTabIndex(index: number): number {
    const stepsLength = this.steps.length;
    if (!stepsLength) {
      return -1;
    }

    for (let step = 1; step <= stepsLength; step += 1) {
      const prevIndex = index - step;
      const nextIndex = index + step;
      if (this.steps[prevIndex] && !this.steps[prevIndex].disabled) {
        return prevIndex;
      }
      if (this.steps[nextIndex] && !this.steps[nextIndex].disabled) {
        return nextIndex;
      }
    }

    return -1;
  }

  protected hasAvailablesteps(index: number): boolean {
    const stepsLength = this.steps.length;
    if (!stepsLength) {
      return false;
    }

    for (let i = 0; i < stepsLength; i += 1) {
      if (!this.steps[i].disabled && i !== index) {
        return true;
      }
    }

    return false;
  }

  protected setClassMap(): void {
   /* this.classMap = {
      'nav-stacked': this.vertical,
      'flex-column': this.vertical,
      'nav-justified': this.justified,
      [`nav-${this.type}`]: true
    };*/
  }
}
