export enum StepperState {
    DONE = "done",
    PENDING = "pending",
    CURRENT = "current"
}