export interface StepperPage {
	page: string;
}