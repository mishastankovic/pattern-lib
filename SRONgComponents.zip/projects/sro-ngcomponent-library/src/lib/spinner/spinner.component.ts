import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { SpinnerService } from './spinner.service';

@Component({
	selector: 'sro-spinner',
	templateUrl: './spinner.component.html',
	styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {

	show: boolean = false;

	private subscription: Subscription;

	constructor(private spinnerService: SpinnerService) { }

	ngOnInit() {
		this.subscription = this.spinnerService.spinnerState
			.subscribe((state: boolean) => {
				this.show = state;
			});
	}

	ngOnDestroy() {
		this.subscription.unsubscribe();
	}

}
