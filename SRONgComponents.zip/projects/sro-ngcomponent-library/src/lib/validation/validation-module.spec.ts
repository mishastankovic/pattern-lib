import { ValidationModule } from './validation-module';

describe('ValidationModuleModule', () => {
  let validationModule: ValidationModule;

  beforeEach(() => {
    validationModule = new ValidationModule();
  });

  it('should create an instance', () => {
    expect(validationModule).toBeTruthy();
  });
});
