import {Directive, ElementRef} from '@angular/core';
import {AbstractControl, NG_VALIDATORS, ValidationErrors} from "@angular/forms";
import {SroValidators} from "../sro-validators";

@Directive({
  selector: '[sro-phone]',
    providers: [{provide: NG_VALIDATORS, useExisting: PhoneDirective, multi: true}]
})
export class PhoneDirective {

    constructor() {}

    validate(c: AbstractControl): ValidationErrors {
      return SroValidators.ausmobile(c);
    }

}
