export { EmailDirective } from './email/email.directive';
export { PhoneDirective } from './phone/phone.directive';