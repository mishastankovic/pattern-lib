import {Directive, ElementRef} from '@angular/core';
import {AbstractControl, NG_VALIDATORS, ValidationErrors, Validator, Validators} from "@angular/forms";
import {SroValidators} from "../sro-validators";

@Directive({
  selector: '[sro-email]',
  providers: [{provide: NG_VALIDATORS, useExisting: EmailDirective, multi: true}]
})
export class EmailDirective implements Validator {

  constructor() {}

  validate(c: AbstractControl): ValidationErrors {
      return Validators.email(c);
  }

}
