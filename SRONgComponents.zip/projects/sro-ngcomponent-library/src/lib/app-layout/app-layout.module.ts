import {NgModule} from '@angular/core';
import {CommonModule} from "@angular/common";
import {ApplayoutComponent} from "./app-layout.component";
import {HeaderModule} from "../header/header.module";
import {FooterModule} from "../footer/footer.module";


@NgModule({
    imports: [CommonModule, HeaderModule, FooterModule],
    declarations: [ApplayoutComponent],
    exports: [ApplayoutComponent]
})
export class ApplayoutModule {
}
