import {CommonModule} from "@angular/common";
import { Component, OnInit, NgModule } from '@angular/core';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { Input } from "@angular/core";
import { Output } from "@angular/core";
import { EventEmitter } from "@angular/core";



@Component({
	selector: 'sro-app-layout',
	templateUrl: './app-layout.component.html',
	styleUrls: ['./app-layout.component.scss']
})
export class ApplayoutComponent implements OnInit {

	@Input('title') title: string;

	@Input('username') username: string;

	@Input('enableLogout') enableLogout: boolean = false;

	@Output('logout') logoutEvent = new EventEmitter();

	isLoggedOut = false;

	constructor() { }

	ngOnInit() {
	}

	logout() {
		this.isLoggedOut = true;
		this.logoutEvent.emit();
	}
}

