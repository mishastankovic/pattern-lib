import {Component, OnInit} from '@angular/core';
import {CommonModule} from "@angular/common";


@Component({
	selector: 'sro-footer',
	templateUrl: './footer.component.html',
	styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

	backToTop: boolean = false;

	constructor() {
	}

	ngOnInit() {
		let _that = this;
        window.onscroll = function() {
            _that.backToTop = document.documentElement.scrollTop > 140;
        };
	}
	public onScrollToTop(): void {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }

    public isSrollToTop(): boolean {
        return document.documentElement.scrollTop > 140;
	}
}


