import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { TypeaheadMatch } from '../typeahead';

import { Address } from '../model/address';
import { ReferenceData } from '../model/reference-data';
import { FormUtils } from '../utils/form-utils';

import { IntechService } from '../service/intech.service';
import { ReferenceDataService } from '../service/reference-data.service';
import { ReferenceDataUtils } from '../utils/reference-data-utils';

import { Observable, Subject, Subscription, of } from "rxjs";
import { mergeMap } from 'rxjs/operators';
import { AddressValidator } from './address.validator';

@Component({
	selector: 'sro-app-address',
	templateUrl: './address.component.html',
	styleUrls: ['./address.component.scss'],
	providers: [IntechService]
})

export class AddressComponent implements OnInit, OnDestroy {

	@Input('id')
	id: number;

	@Input('label')
	label: string;

	@Input('address')
	address: Address;

	@Input('vicOnly')
	vicOnly: boolean = false;

	@Input('readOnly')
	readOnly: boolean = false;

	@Input('noPostal')
	noPostal: boolean = false;

	@Output()
	private formReady: EventEmitter<FormGroup> = new EventEmitter<FormGroup>();

	@Output()
	private formRemove: EventEmitter<FormGroup> = new EventEmitter<FormGroup>();

	form: FormGroup;
	referenceData: ReferenceData[];

	private results: string[] = [];
	private subscriptions: Subscription[] = [];
	//private searchAddressLine = new Subject<string>();

	dataSource: Observable<any>;
	private typeaheadLoading: boolean;

	constructor(private intechService: IntechService, private referenceDataService: ReferenceDataService, private formBuilder: FormBuilder, private referenceDataUtils: ReferenceDataUtils) {
		this.dataSource = Observable.create((observer: any) => {
			// Runs on every search
			observer.next(this.form.get('addressLine').value);
		})
			.pipe(
			mergeMap((addressLineInput: string) => this.searchIntechAddress(addressLineInput))
			);
	}

	ngOnInit() {
		this.referenceData = this.referenceDataService.getReferenceData();

		// If address has not been preset, then initialize a new one
		if (!this.address) this.address = Address.createAddress();

		this.form = this.formBuilder.group({
			addressFormatType: [this.address.addressFormatType, Validators.required],
			addressLine: [this.address.addressLine, Validators.compose([Validators.required, Validators.maxLength(120)])],
			flatUnitType: [this.address.flatUnitType, Validators.compose([Validators.maxLength(7)])],
			flatUnitNumber: [this.address.flatUnitNumber, Validators.compose([Validators.maxLength(7)])],
			floorLevelType: [this.address.floorLevelType, Validators.compose([Validators.maxLength(2)])],
			floorLevelNumber: [this.address.floorLevelNumber, Validators.compose([Validators.maxLength(5)])],
			lotNumber: [this.address.lotNumber, Validators.compose([Validators.required, Validators.maxLength(6)])],
			buildingName: [this.address.buildingName, Validators.compose([Validators.maxLength(30)])],
			streetNumberFrom: [this.address.roadNumberFrom, Validators.compose([Validators.required, Validators.maxLength(6), AddressValidator.validateRoadNumber()])],
			streetNumberTo: [this.address.roadNumberTo, Validators.compose([Validators.maxLength(6), AddressValidator.validateRoadNumber()])],
			streetName: [this.address.roadName, Validators.compose([Validators.required, Validators.maxLength(30)])],
			streetType: [this.address.roadType, Validators.compose([Validators.maxLength(4)])],
			streetSuffixType: [this.address.roadSuffixType, Validators.compose([Validators.maxLength(2)])],
			locality: [this.address.localityName, Validators.compose([Validators.required, Validators.maxLength(46)])],
			state: [this.address.stateTerritory, Validators.compose([Validators.required, AddressValidator.validateState(this.vicOnly)])],
			postcode: [this.address.postcode, Validators.compose([Validators.required, Validators.maxLength(4), AddressValidator.validatePostcode()])],
			postalBoxType: [this.address.postalDeliveryType, Validators.compose([Validators.required, Validators.maxLength(100)])],
			postalBoxPrefix: [this.address.postalDeliveryPrefix, Validators.compose([Validators.maxLength(3)])],
			postalBoxDeliveryNumber: [this.address.postalDeliveryNumber, Validators.compose([Validators.required, Validators.maxLength(5)])],
			postalBoxSuffix: [this.address.postalDeliverySuffix, Validators.compose([Validators.maxLength(3)])],
			overseasAddressLine1: [this.address.overseasAddressLine1, Validators.compose([Validators.required, Validators.maxLength(60)])],
			overseasAddressLine2: [this.address.overseasAddressLine2, Validators.compose([Validators.maxLength(60)])],
			overseasAddressLine3: [this.address.overseasAddressLine3, Validators.compose([Validators.maxLength(60)])],
			country: [this.address.country, Validators.compose([Validators.required, Validators.maxLength(100)])]
		});
		this.formReady.emit(this.form);

		this.subscriptions.push(
			this.form.get('addressFormatType').valueChanges.subscribe(
				data => { this.onValueChanged(this.form) }));
		this.onValueChanged(<FormGroup>this.form);
	}

	ngOnDestroy() {
		this.subscriptions.forEach((subscription: Subscription) => {
			subscription.unsubscribe();
		});
		this.formRemove.emit(this.form);
	}

	onAddressChange() {
		if (this.form.get('addressFormatType').value === Address.FREETEXT) {
			this.form.get('addressFormatType').setValue(Address.STREET);
			if (this.isVicOnly()) this.form.get('state').setValue(Address.VIC);
		} else {
			this.form.get('addressFormatType').setValue(Address.FREETEXT);
		}
		this.onValueChanged(this.form);
	}

	searchIntechAddress(addressLineInput: string): Observable<any> {
		return this.intechService.search(addressLineInput, String(this.vicOnly), String(this.noPostal));
	}

	isReadOnly(): boolean {
		return this.readOnly && this.readOnly === true;
	}

	isVicOnly(): boolean {
		return this.vicOnly && this.vicOnly === true;
	}

	isFreeTextAddress(): boolean {
		return this.form.get('addressFormatType') && this.form.get('addressFormatType').value === Address.FREETEXT;
	}

	isStreetAddress(): boolean {
		return this.form.get('addressFormatType') && this.form.get('addressFormatType').value === Address.STREET;
	}

	isLotAddress(): boolean {
		return this.form.get('addressFormatType') && this.form.get('addressFormatType').value === Address.LOT;
	}

	isPostalAddress(): boolean {
		return this.form.get('addressFormatType') && this.form.get('addressFormatType').value === Address.POSTAL;
	}

	isOverseasAddress(): boolean {
		return this.form.get('addressFormatType') && this.form.get('addressFormatType').value === Address.OVERSEAS;
	}

	getId(): number {
		return this.id ? this.id : 1;
	}

	getLabel(): string {
		return this.label ? this.label : 'address';
	}

	getAddressFormatTypes(): ReferenceData[] {
		//return this.referenceData.filter(item => item.type === ReferenceDataService.ADDRESS_TYPES);
		return this.noPostal === true ?
			(this.vicOnly === true ? this.referenceData.filter(item => item.type === ReferenceDataService.NON_POSTAL_ADDRESS_TYPES && item.code !== Address.OVERSEAS) : this.referenceData.filter(item => item.type === ReferenceDataService.NON_POSTAL_ADDRESS_TYPES))
			: this.referenceData.filter(item => item.type === ReferenceDataService.ADDRESS_TYPES);
	}
	getCountries(): string {
		return ReferenceDataService.COUNTRIES;
	}

	getFlatUnitTypes(): string {
		return ReferenceDataService.FLAT_UNIT_TYPES;
	}

	getFloorLevelTypes(): string {
		return ReferenceDataService.FLOOR_LEVEL_TYPES;
	}

	getPostalBoxTypes(): string {
		return ReferenceDataService.POSTAL_BOX_TYPES;
	}

	getStates(): string {
		return ReferenceDataService.STATES;
	}

	getStreetSuffixes() {
		return ReferenceDataService.STREET_SUFFIXES;
	}

	getStreetTypes(): string {
		return ReferenceDataService.STREET_TYPES;
	}

	isNotValid(control: AbstractControl, type?: string): boolean {
		return FormUtils.isNotValid(control, type);
	}

	onValueChanged(control: AbstractControl) {
		if (!control || !(control instanceof FormGroup)) return;

		const formGroup: FormGroup = <FormGroup>control;
		FormUtils.disableControl([
			formGroup.get('addressLine'),
			formGroup.get('lotNumber'),
			formGroup.get('streetNumberFrom'),
			formGroup.get('streetName'),
			formGroup.get('locality'),
			formGroup.get('state'),
			formGroup.get('postcode'),
			formGroup.get('postalBoxType'),
			formGroup.get('postalBoxDeliveryNumber'),
			formGroup.get('overseasAddressLine1'),
			formGroup.get('overseasAddressLine2'),
			formGroup.get('overseasAddressLine3'),
			formGroup.get('country')
		]);

		if (formGroup.get('addressFormatType').value === Address.FREETEXT) {
			FormUtils.enableControl([formGroup.get('addressLine')]);

		} else if (formGroup.get('addressFormatType').value === Address.STREET) {
			FormUtils.enableControl([
				formGroup.get('streetNumberFrom'),
				formGroup.get('streetName'),
				formGroup.get('locality'),
				formGroup.get('state'),
				formGroup.get('postcode')
			]);

		} else if (formGroup.get('addressFormatType').value === Address.LOT) {
			FormUtils.enableControl([
				formGroup.get('lotNumber'),
				formGroup.get('streetName'),
				formGroup.get('locality'),
				formGroup.get('state'),
				formGroup.get('postcode')
			]);

		} else if (formGroup.get('addressFormatType').value === Address.POSTAL) {
			FormUtils.enableControl([
				formGroup.get('postalBoxType'),
				formGroup.get('postalBoxDeliveryNumber'),
				formGroup.get('locality'),
				formGroup.get('state'),
				formGroup.get('postcode')
			]);

		} else if (formGroup.get('addressFormatType').value === Address.OVERSEAS) {
			FormUtils.enableControl([
				formGroup.get('overseasAddressLine1'),
				formGroup.get('overseasAddressLine2'),
				formGroup.get('overseasAddressLine3'),
				formGroup.get('country')
			]);
		}
	}

	standardiseAddressOnSubmit(group: AbstractControl): Observable<Address> {
		return this.standardiseAddress(group.get("addressLine").value, <FormGroup>group);
	}

	standardiseAddress(addressLine: string, group: FormGroup): Observable<Address> {
		return this.intechService.standardise(addressLine);
	}

	toAddressObject(data: Address): Address {
		if (data && data.addressFormatType) {
			return new Address(data.addressFormatType,
				data.addressLine,
				data.flatUnitType,
				data.flatUnitNumber,
				data.floorLevelType,
				data.floorLevelNumber,
				data.buildingName,
				data.lotNumber,
				data.roadNumberFrom,
				data.roadNumberFromSuffix,
				data.roadNumberTo,
				data.roadNumberToSuffix,
				data.roadName,
				data.roadType,
				data.roadSuffixType,
				data.postalDeliveryType,
				data.postalDeliveryPrefix,
				data.postalDeliveryNumber,
				data.postalDeliverySuffix,
				data.localityName,
				data.postcode,
				data.stateTerritory,
				data.overseasAddressLine1,
				data.overseasAddressLine2,
				data.overseasAddressLine3,
				data.country);
		} else {
			return null;
		}
	}

	setStructuredAddress(formGroup: FormGroup, address: Address) {
		FormUtils.disableControl([
			formGroup.get('lotNumber'),
			formGroup.get('streetNumberFrom'),
			formGroup.get('streetName'),
			formGroup.get('locality'),
			formGroup.get('state'),
			formGroup.get('postcode'),
			formGroup.get('postalBoxType'),
			formGroup.get('postalBoxDeliveryNumber'),
			formGroup.get('overseasAddressLine1'),
			formGroup.get('overseasAddressLine2'),
			formGroup.get('overseasAddressLine3'),
			formGroup.get('country')
		]);

		if (address.addressFormatType === Address.INTECH_STREET) {
			FormUtils.enableAndTouchControl([
				formGroup.get('streetNumberFrom'),
				formGroup.get('streetName'),
				formGroup.get('locality'),
				formGroup.get('state'),
				formGroup.get('postcode')
			]);
			formGroup.get('streetNumberFrom').setValue(address.roadNumberFrom);
			formGroup.get('streetName').setValue(address.roadName);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.addressFormatType === Address.INTECH_LOT) {
			FormUtils.enableAndTouchControl([
				formGroup.get('lotNumber'),
				formGroup.get('streetName'),
				formGroup.get('locality'),
				formGroup.get('state'),
				formGroup.get('postcode')
			]);
			formGroup.get('lotNumber').setValue(address.lotNumber);
			formGroup.get('streetName').setValue(address.roadName);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.addressFormatType === Address.INTECH_POSTAL) {
			FormUtils.enableAndTouchControl([
				formGroup.get('postalBoxType'),
				formGroup.get('postalBoxDeliveryNumber'),
				formGroup.get('locality'),
				formGroup.get('state'),
				formGroup.get('postcode')
			]);
			formGroup.get('postalBoxType').setValue(address.postalDeliveryType);
			formGroup.get('postalBoxDeliveryNumber').setValue(address.postalDeliveryNumber);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.addressFormatType === Address.INTECH_OVERSEAS) {
			FormUtils.enableAndTouchControl([
				formGroup.get('overseasAddressLine1'),
				formGroup.get('overseasAddressLine2'),
				formGroup.get('overseasAddressLine3'),
				formGroup.get('country')
			]);
			formGroup.get('overseasAddressLine1').setValue(address.overseasAddressLine1);
			formGroup.get('overseasAddressLine2').setValue(address.overseasAddressLine2);
			formGroup.get('overseasAddressLine3').setValue(address.overseasAddressLine3);
			formGroup.get('country').setValue(address.country);
		}

		// This will set the complete structured address back to the free text but format is different from dropdown value
		// So will not use this unless required
		//formGroup.get('addressLine').setValue(address.formattedAddress);
	}

	isFreeTextAddressFormatType(formGroup: FormGroup) {
		return formGroup && formGroup.get('addressLine') && formGroup.get('addressLine').value && formGroup.get('addressFormatType').value === Address.FREETEXT;
	}


	changeTypeaheadLoading(e: boolean): void {
		this.typeaheadLoading = e;
	}

	typeaheadOnSelect(e: TypeaheadMatch): void {
		console.log('Selected value: ', e.value);
	}

	// Mapper functions
	mapFormToAddress(control: AbstractControl): Address {
		if (!(control instanceof FormGroup)) return Address.createAddress();
		const formGroup: FormGroup = <FormGroup>control;

		const address: Address = Address.createAddress();
		address.addressFormatType = formGroup.get('addressFormatType').value;

		if (address.isFreeTextAddress()) {
			address.addressLine = formGroup.get('addressLine').value;

		} else if (address.isStreetAddress()) {
			address.flatUnitType = formGroup.get('flatUnitType').value;
			address.flatUnitNumber = formGroup.get('flatUnitNumber').value;
			address.floorLevelType = formGroup.get('floorLevelType').value;
			address.floorLevelNumber = formGroup.get('floorLevelNumber').value;
			address.buildingName = formGroup.get('buildingName').value;
			address.roadNumberFrom = formGroup.get('streetNumberFrom').value;
			address.roadNumberTo = formGroup.get('streetNumberTo').value;
			address.roadName = formGroup.get('streetName').value;
			address.roadType = formGroup.get('streetType').value;
			address.roadSuffixType = formGroup.get('streetSuffixType').value;
			address.localityName = formGroup.get('locality').value;
			address.stateTerritory = formGroup.get('state').value;
			address.postcode = formGroup.get('postcode').value;

		} else if (address.isLotAddress()) {
			address.lotNumber = formGroup.get('lotNumber').value;
			address.roadName = formGroup.get('streetName').value;
			address.roadType = formGroup.get('streetType').value;
			address.roadSuffixType = formGroup.get('streetSuffixType').value;
			address.localityName = formGroup.get('locality').value;
			address.stateTerritory = formGroup.get('state').value;
			address.postcode = formGroup.get('postcode').value;

		} else if (address.isPostalAddress()) {
			address.postalDeliveryType = formGroup.get('postalBoxType').value;
			address.postalDeliveryPrefix = formGroup.get('postalBoxPrefix').value;
			address.postalDeliveryNumber = formGroup.get('postalBoxDeliveryNumber').value;
			address.postalDeliverySuffix = formGroup.get('postalBoxSuffix').value;
			address.buildingName = formGroup.get('buildingName').value;
			address.localityName = formGroup.get('locality').value;
			address.stateTerritory = formGroup.get('state').value;
			address.postcode = formGroup.get('postcode').value;

		} else if (address.isOverseasAddress()) {
			address.overseasAddressLine1 = formGroup.get('overseasAddressLine1').value;
			address.overseasAddressLine2 = formGroup.get('overseasAddressLine2').value;
			address.overseasAddressLine3 = formGroup.get('overseasAddressLine3').value;
			address.country = formGroup.get('country').value;
		}

		return address;
	}

	mapAddressToForm(control: AbstractControl, address: Address) {
		if (!(control instanceof FormGroup) || !address) return;
		const formGroup: FormGroup = <FormGroup>control;

		formGroup.get('addressFormatType').setValue(address.addressFormatType);

		if (address.isFreeTextAddress()) {
			formGroup.get('addressLine').setValue(address.addressLine);

		} else if (address.isStreetAddress()) {
			formGroup.get('flatUnitType').setValue(address.flatUnitType);
			formGroup.get('flatUnitNumber').setValue(address.flatUnitNumber);
			formGroup.get('floorLevelType').setValue(address.floorLevelType);
			formGroup.get('floorLevelNumber').setValue(address.floorLevelNumber);
			formGroup.get('buildingName').setValue(address.buildingName);
			formGroup.get('streetNumberFrom').setValue(address.roadNumberFrom);
			formGroup.get('streetNumberTo').setValue(address.roadNumberTo);
			formGroup.get('streetName').setValue(address.roadName);
			formGroup.get('streetType').setValue(address.roadType);
			formGroup.get('streetSuffixType').setValue(address.roadSuffixType);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.isPostalAddress()) {
			formGroup.get('postalBoxType').setValue(address.postalDeliveryType);
			formGroup.get('postalBoxPrefix').setValue(address.postalDeliveryPrefix);
			formGroup.get('postalBoxDeliveryNumber').setValue(address.postalDeliveryNumber);
			formGroup.get('postalBoxSuffix').setValue(address.postalDeliverySuffix);
			formGroup.get('buildingName').setValue(address.buildingName);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.isOverseasAddress()) {
			formGroup.get('overseasAddressLine1').setValue(address.overseasAddressLine1);
			formGroup.get('overseasAddressLine2').setValue(address.overseasAddressLine2);
			formGroup.get('overseasAddressLine3').setValue(address.overseasAddressLine3);
			formGroup.get('country').setValue(address.country);
		}
	}

	toFormattedAddress(address: Address): string {
		if (!address || !this.referenceDataUtils) return "";

		if (address.isFreeTextAddress()) {
			return address.addressLine;
		}

		var formattedAddress: string = '';
		const SPACE: string = ' ';

		if (address.isStreetAddress()) {
			if (address.flatUnitType && address.flatUnitType != '') {
				formattedAddress += this.referenceDataUtils.getFlatUnitTypesLabel(address.flatUnitType);
				formattedAddress += SPACE;
			}

			if (address.flatUnitNumber && address.flatUnitNumber != '') {
				formattedAddress += address.flatUnitNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.floorLevelType && address.floorLevelType != '') {
				formattedAddress += this.referenceDataUtils.getFloorLevelTypesLabel(address.floorLevelType);
				formattedAddress += SPACE;
			}

			if (address.floorLevelNumber && address.floorLevelNumber != '') {
				formattedAddress += address.floorLevelNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.buildingName && address.buildingName != '') {
				formattedAddress += address.buildingName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadNumberFrom && address.roadNumberFrom != '') {
				formattedAddress += address.roadNumberFrom.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadNumberTo && address.roadNumberTo != '') {
				formattedAddress += address.roadNumberTo.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadName && address.roadName != '') {
				formattedAddress += address.roadName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadType && address.roadType != null) {
				formattedAddress += this.referenceDataUtils.getRoadTypesLabel(address.roadType);
				formattedAddress += SPACE;
			}

			if (address.roadSuffixType && address.roadSuffixType != null) {
				formattedAddress += this.referenceDataUtils.getRoadSuffixTypesLabel(address.roadSuffixType);
				formattedAddress += SPACE;
			}

			if (address.localityName && address.localityName != '') {
				formattedAddress += address.localityName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.stateTerritory && address.stateTerritory != null) {
				formattedAddress += address.stateTerritory.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postcode && address.postcode != '') {
				formattedAddress += address.postcode;
			}

		} else if (address.isLotAddress()) {

			if (address.lotNumber && address.lotNumber != '') {
				formattedAddress += address.lotNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadName && address.roadName != '') {
				formattedAddress += address.roadName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadType && address.roadType != null) {
				formattedAddress += this.referenceDataUtils.getRoadTypesLabel(address.roadType);
				formattedAddress += SPACE;
			}

			if (address.roadSuffixType && address.roadSuffixType != null) {
				formattedAddress += this.referenceDataUtils.getRoadSuffixTypesLabel(address.roadSuffixType);;
				formattedAddress += SPACE;
			}

			if (address.localityName && address.localityName != '') {
				formattedAddress += address.localityName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.stateTerritory && address.stateTerritory != null) {
				formattedAddress += address.stateTerritory.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postcode && address.postcode != '') {
				formattedAddress += address.postcode;
			}

		} else if (address.isPostalAddress()) {

			if (address.postalDeliveryType && address.postalDeliveryType != null) {
				formattedAddress += this.referenceDataUtils.getPostalDeliveryTypesLabel(address.postalDeliveryType);
				formattedAddress += SPACE;
			}

			if (address.postalDeliveryPrefix && address.postalDeliveryPrefix != '') {
				formattedAddress += address.postalDeliveryPrefix.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postalDeliveryNumber && address.postalDeliveryNumber != '') {
				formattedAddress += address.postalDeliveryNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postalDeliverySuffix && address.postalDeliverySuffix != '') {
				formattedAddress += address.postalDeliverySuffix.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.buildingName && address.buildingName != '') {
				formattedAddress += address.buildingName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.localityName && address.localityName != '') {
				formattedAddress += address.localityName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.stateTerritory && address.stateTerritory != '') {
				formattedAddress += address.stateTerritory.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postcode && address.postcode != '') {
				formattedAddress += address.postcode;
			}

		} else if (address.isOverseasAddress()) {
			if (address.overseasAddressLine1 && address.overseasAddressLine1 != '') {
				formattedAddress += address.overseasAddressLine1.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.overseasAddressLine2 && address.overseasAddressLine2 != '') {
				formattedAddress += address.overseasAddressLine2.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.overseasAddressLine3 && address.overseasAddressLine3 != '') {
				formattedAddress += address.overseasAddressLine3.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.country && address.country != '') {
				formattedAddress += this.referenceDataUtils.getCountryLabel(address.country);
			}
		}

		return formattedAddress;

	}

}
