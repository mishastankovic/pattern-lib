import { AbstractControl, ValidatorFn } from '@angular/forms';

import { Address } from '../model/address';


// @dynamic
export class AddressValidator {

	static validateRoadNumber(): ValidatorFn {
		var pattern = /^[0-9]{1,5}[a-zA-Z]?$/;
		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = pattern.test(control.value);
			}
			return valid ? null : { 'roadNumberFormat': { value: control.value } };
		};
	}

	static validatePostcode(): ValidatorFn {
		var pattern = /^[0-9]{4}$/;
		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = pattern.test(control.value);
			}
			return valid ? null : { 'postcodeFormat': { value: control.value } };
		};
	}

	static validateState(vicOnly: boolean): ValidatorFn {
		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (vicOnly && control && control.value && control.value != Address.VIC) {
				valid = false;
			}
			return valid ? null : { 'stateFormat': { value: control.value } };
		};
	}
} 