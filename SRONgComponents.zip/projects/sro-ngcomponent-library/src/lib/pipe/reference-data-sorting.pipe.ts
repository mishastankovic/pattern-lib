import { Pipe, PipeTransform } from '@angular/core';

import { ReferenceData } from "../model/reference-data";

@Pipe({
	name: 'referenceDataSorter'
})
export class ReferenceDataSortingPipe implements PipeTransform {

	transform(referenceData: ReferenceData[]): ReferenceData[] {
		if (!referenceData) return null;

		return referenceData.sort((r1, r2) => r1.label < r2.label ? -1 : r1.label > r2.label ? 1 : 0);
	}

}
