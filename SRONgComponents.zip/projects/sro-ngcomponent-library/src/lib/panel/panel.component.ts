import { CommonModule } from '@angular/common';
import {Component, Input, OnInit, NgModule, ModuleWithProviders, ViewEncapsulation} from '@angular/core';


@Component({
  selector: 'sro-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PanelComponent implements OnInit {

    /**
     * optional class attribute coming from sro-panel tag
     */
  @Input() styleClass: string;

  @Input() callout: boolean;

  @Input() title: string;

  @Input("alertType") style: string;


  constructor() { }

  ngOnInit() {
  }

}

@NgModule({
    imports: [CommonModule],
    exports: [PanelComponent],
    declarations: [PanelComponent]
})
export class PanelModule { }