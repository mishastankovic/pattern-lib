import { Injectable } from "@angular/core";

import { ReferenceDataService } from "../service/reference-data.service";
import { ReferenceData } from "../model/reference-data";

@Injectable()
export class ReferenceDataUtils {

	referenceData: ReferenceData[];

	constructor(private referenceDataService: ReferenceDataService) {
		this.referenceData = this.referenceDataService.getReferenceData();
	}

	getFlatUnitTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.FLAT_UNIT_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getFloorLevelTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.FLOOR_LEVEL_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getRoadSuffixTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.STREET_SUFFIXES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getRoadTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.STREET_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getPostalDeliveryTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.POSTAL_BOX_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getCountryLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.COUNTRIES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getTrustTypeLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.TRUST_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}
}