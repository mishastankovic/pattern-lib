export const environment = {
	production: true,
	localtest: false,
	serviceHostname: '',
	intechSearchServicePath: '',
	intechStandardiseServicePath: ''
};
